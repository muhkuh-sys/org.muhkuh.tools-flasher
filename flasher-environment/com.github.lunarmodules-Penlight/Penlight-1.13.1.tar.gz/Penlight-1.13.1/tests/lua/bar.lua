--- test module for demonstrating app.require_here()
local bar = {}

function bar.name ()
    return 'bar'
end

return bar


