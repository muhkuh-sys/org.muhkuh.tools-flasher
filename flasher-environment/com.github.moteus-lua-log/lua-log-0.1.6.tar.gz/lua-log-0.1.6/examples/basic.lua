local log = require "log".new()

log.error('Hello')
log.warning(', ')
log.info('world')
log.notice('!!!')
log.debug('Does not displayed')
